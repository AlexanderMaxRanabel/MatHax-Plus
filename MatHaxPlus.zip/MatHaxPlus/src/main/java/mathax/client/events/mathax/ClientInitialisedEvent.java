package mathax.client.events.mathax;

@Deprecated
public class ClientInitialisedEvent {
}
