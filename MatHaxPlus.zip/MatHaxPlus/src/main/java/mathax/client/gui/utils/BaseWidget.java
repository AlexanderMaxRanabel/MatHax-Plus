package mathax.client.gui.utils;

import mathax.client.gui.GuiTheme;

public interface BaseWidget {
    GuiTheme getTheme();
}
