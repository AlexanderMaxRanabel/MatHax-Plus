package mathax.client.gui.utils;

public interface CharFilter {
    boolean filter(String text, char c);
}
