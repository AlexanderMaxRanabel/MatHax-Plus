package mathax.client.gui;

public class GuiKeyEvents {
    public static boolean canUseKeys = true;
}
