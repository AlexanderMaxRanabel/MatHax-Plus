package mathax.client.gui.widgets;

public interface WRoot {
}
