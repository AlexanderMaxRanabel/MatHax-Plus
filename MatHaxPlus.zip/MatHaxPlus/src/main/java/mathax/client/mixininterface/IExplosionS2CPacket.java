package mathax.client.mixininterface;

public interface IExplosionS2CPacket {
    void setVelocityX(float velocity);

    void setVelocityY(float velocity);

    void setVelocityZ(float velocity);
}
