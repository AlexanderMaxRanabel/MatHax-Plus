package mathax.client.mixininterface;

public interface IClientPlayerInteractionManager {
    void syncSelected();
}
