package mathax.client.mixininterface;

public interface IPlayerMoveC2SPacket {
    int getNbt();
    void setNbt(int tag);
}
