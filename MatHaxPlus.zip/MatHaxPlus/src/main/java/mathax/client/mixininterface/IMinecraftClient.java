package mathax.client.mixininterface;

public interface IMinecraftClient {
    void rightClick();
}
