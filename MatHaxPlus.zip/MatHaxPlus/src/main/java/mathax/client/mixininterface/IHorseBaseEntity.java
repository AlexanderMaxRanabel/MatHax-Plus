package mathax.client.mixininterface;

public interface IHorseBaseEntity {
    void setSaddled(boolean saddled);
}
