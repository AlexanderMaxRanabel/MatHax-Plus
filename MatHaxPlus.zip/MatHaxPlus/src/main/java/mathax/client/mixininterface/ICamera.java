package mathax.client.mixininterface;

public interface ICamera {
    void setRot(double yaw, double pitch);
}
