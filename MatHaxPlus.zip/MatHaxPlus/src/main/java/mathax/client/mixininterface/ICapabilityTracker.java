package mathax.client.mixininterface;

public interface ICapabilityTracker {
    boolean get();

    void set(boolean state);
}
