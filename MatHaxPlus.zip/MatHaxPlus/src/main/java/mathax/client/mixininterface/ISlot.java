package mathax.client.mixininterface;

public interface ISlot {
    int getId();

    int getIndex();
}
