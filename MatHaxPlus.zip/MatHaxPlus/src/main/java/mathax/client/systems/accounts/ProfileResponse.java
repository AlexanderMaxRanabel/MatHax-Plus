package mathax.client.systems.accounts;

public class ProfileResponse {
    public String id;
}
