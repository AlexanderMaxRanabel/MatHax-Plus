package mathax.client.settings;

public interface IVisible {
    boolean isVisible();
}
